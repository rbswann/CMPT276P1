/*

Written by: Yufeng Luo

 */
package com.group04.studentaide;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;


public class coursesActivity extends AppCompatActivity {

    Button createCourseClicked;
    Spinner coursesDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        /*createCourseClicked.findViewById(R.id.courseCreate);

        createCourseClicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                courseCreate(v);
            }
        });*/

        CourseSingleton courseList = CourseSingleton.getInstance();
        ArrayList<String> hashKeys = courseList.courseKeys;

        coursesDisplay = findViewById(R.id.courseDropdown);
        //Set spinner adapter
        ArrayAdapter<String> arrAdapt = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, hashKeys);
        coursesDisplay.setAdapter(arrAdapt);
        coursesDisplay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String choice = parent.getItemAtPosition(position).toString();
                //random data inserted to see what appears
                Double choiceTime = courseList.getStudyTime(choice);
                Toast.makeText(getApplicationContext(), choice + ": " + choiceTime, Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    public void courseCreate(View view){
        Intent create = new Intent(this, courseCreation.class);
        startActivity(create);
    }


    /*
    //This is code for spinner --> need arrayadapter and hashmap key values in the spinner
    //Get a reference to the new update Hashmap and arraylist when reopening activity

    CourseSingleton courseList = CourseSingleton.getInstance();
    ArrayList<String> hashKeys = courseList.courseKeys;

    Spinner coursesDisplay = findViewById(R.id.courseDropdown);
    //Set spinner adapter
    ArrayAdapter<String> arrAdapt = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, hashKeys);
    coursesDisplay.setAdapter(arrAdapt);
    coursesDisplay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String choice = parent.getItemAtPosition(position).toString();
            //random data inserted to see what appears
            courseList.setStudyTime("General", 16.3);
            courseList.setStudyTime(choice, 12.3);
            Double choiceTime = courseList.getStudyTime(choice);
            Double time = courseList.getStudyTime("General");
            Toast.makeText(getApplicationContext(), "General: " + time + choice + ":" + choiceTime, Toast.LENGTH_SHORT).show();
        }
        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    });
    */



    /*
    To be completed in later versions
    public void courseSelect(){
    }
    public void courseJoin(){
    }
     */

}