package com.group04.studentaide;

import android.content.Context;
import android.content.SharedPreferences;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class registrationTest {

    SharedPreferences pref = getApplicationCcontext().getSharedPreferences("TEST", 0);

    private Context getApplicationCcontext() {
       return getApplicationCcontext();
    }

    SharedPreferences.Editor preferencesEditor = pref.edit();

    @Test
    public void registerUser() {
        String fname="jim";
        preferencesEditor.putString("First name",fname);

        assertEquals(R.id.firstNameInput,fname);

    }
}