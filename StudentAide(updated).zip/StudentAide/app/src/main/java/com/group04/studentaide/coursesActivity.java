/*

Written by: Yufeng Luo

 */
package com.group04.studentaide;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class coursesActivity extends AppCompatActivity {

    Button createCourseClicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        /*createCourseClicked.findViewById(R.id.courseCreate);

        createCourseClicked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                courseCreate(v);
            }
        });*/

    }

    public void courseCreate(View view){
        Intent create = new Intent(this, courseCreation.class);
        startActivity(create);
    }

    /*
    To be completed in later versions

    public void courseSelect(){

    }

    public void courseJoin(){

    }
     */

}